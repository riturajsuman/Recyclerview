package com.example.recyclerview

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview.adapter.CustomAdapter
import com.example.recyclerview.databinding.ActivityMainBinding
import com.example.recyclerview.model.User


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityMainBinding =
            DataBindingUtil.setContentView(this, R.layout.activity_main)

        binding.contactDetail.layoutManager =
            LinearLayoutManager(this, RecyclerView.VERTICAL, false)

        val ser = User("Rituraj suman", "123456")
        val ser1 = User("Rituraj", "9019758277")
        val ser2 = User("Rituraj suman", "82695037")
        val value: ArrayList<User> = ArrayList()
        value.add(ser)
        value.add(ser1)
        value.add(ser2)
        value.add(ser)

        val adapter = CustomAdapter(value)

        binding.contactDetail.adapter = adapter
    }
}
