package com.example.recyclerview.model

data class User(val userName: String, val Contact: String)